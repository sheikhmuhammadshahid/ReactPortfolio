import React from 'react'
import { motion } from 'framer-motion'
import { MapPin, Calendar, ExternalLink } from 'lucide-react'

const Experience: React.FC = () => {
  const experiences = [
    {
      company: 'TechCorp Inc.',
      position: 'Senior Product Designer',
      location: 'San Francisco, CA',
      period: '2022 - Present',
      description: 'Leading design initiatives for B2B SaaS platform serving 10K+ users. Redesigned core user flows resulting in 40% increase in user engagement.',
      achievements: [
        'Led design system implementation across 5 product teams',
        'Increased user satisfaction score from 3.2 to 4.6',
        'Reduced user onboarding time by 60%'
      ],
      technologies: ['Figma', 'React', 'TypeScript', 'Storybook']
    },
    {
      company: 'DesignStudio Pro',
      position: 'Product Designer',
      location: 'New York, NY',
      period: '2020 - 2022',
      description: 'Designed digital experiences for startups and Fortune 500 companies. Specialized in mobile-first design and user research.',
      achievements: [
        'Designed 20+ mobile apps with 4.8+ App Store ratings',
        'Conducted user research for 50+ projects',
        'Mentored 3 junior designers'
      ],
      technologies: ['Sketch', 'InVision', 'Principle', 'Adobe Creative Suite']
    },
    {
      company: 'Creative Agency',
      position: 'UI/UX Designer',
      location: 'Los Angeles, CA',
      period: '2019 - 2020',
      description: 'Created brand identities and digital experiences for diverse clients ranging from startups to established brands.',
      achievements: [
        'Delivered 30+ branding projects on time',
        'Won 2 design awards for mobile app design',
        'Increased client retention rate by 25%'
      ],
      technologies: ['Adobe XD', 'Photoshop', 'Illustrator', 'After Effects']
    },
    {
      company: 'Freelance',
      position: 'Freelance Designer',
      location: 'Remote',
      period: '2018 - 2019',
      description: 'Provided design services to small businesses and startups, focusing on web design and brand identity.',
      achievements: [
        'Completed 15+ web design projects',
        'Built recurring client base of 10+ businesses',
        'Achieved 100% client satisfaction rate'
      ],
      technologies: ['WordPress', 'Webflow', 'Figma', 'Canva']
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { x: -20, opacity: 0 },
    visible: {
      x: 0,
      opacity: 1,
      transition: {
        duration: 0.6,
      },
    },
  }

  return (
    <section id="experience" className="section-padding bg-white">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Work <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A journey through my professional growth and the impact I've made at each step
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="relative"
          >
            {/* Timeline Line */}
            <div className="absolute left-8 md:left-1/2 transform md:-translate-x-px top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary-600 to-secondary-600"></div>

            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className={`relative flex items-center mb-12 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline Node */}
                <div className="absolute left-6 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-white border-4 border-primary-600 rounded-full z-10"></div>

                {/* Content Card */}
                <div className={`ml-16 md:ml-0 md:w-1/2 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 card-hover"
                  >
                    {/* Header */}
                    <div className="mb-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-xl font-bold text-gray-900">{exp.position}</h3>
                        <div className="flex items-center text-gray-500 text-sm">
                          <Calendar className="w-4 h-4 mr-1" />
                          {exp.period}
                        </div>
                      </div>
                      <div className="flex items-center text-primary-600 font-semibold mb-2">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        {exp.company}
                      </div>
                      <div className="flex items-center text-gray-500 text-sm">
                        <MapPin className="w-4 h-4 mr-1" />
                        {exp.location}
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-gray-600 mb-4 leading-relaxed">
                      {exp.description}
                    </p>

                    {/* Achievements */}
                    <div className="mb-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Key Achievements:</h4>
                      <ul className="space-y-1">
                        {exp.achievements.map((achievement, achIndex) => (
                          <li key={achIndex} className="flex items-start text-sm text-gray-600">
                            <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                            {achievement}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Technologies */}
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Technologies:</h4>
                      <div className="flex flex-wrap gap-2">
                        {exp.technologies.map((tech, techIndex) => (
                          <span
                            key={techIndex}
                            className="px-3 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Skills Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-20 text-center"
        >
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Core Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {['Figma', 'Sketch', 'Adobe XD', 'React', 'TypeScript', 'Tailwind CSS', 'User Research', 'Prototyping', 'Design Systems', 'A/B Testing', 'Analytics', 'Mentoring'].map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-r from-primary-600 to-secondary-600 text-white px-4 py-2 rounded-lg text-sm font-medium"
              >
                {skill}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Experience
